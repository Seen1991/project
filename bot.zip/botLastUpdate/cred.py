#Twilio Details

account_sid = 'AC442e3ce355352afa300428dbd6cbda4a'
auth_token = 'f862489c1275df0b337ca7186bd93d59'
twilionumber = '+18882203556'
twiliosmsnumber = '+18882203556'

#FC Bot
API_TOKEN = "6030321994:AAFXZuHFjll6AKSgf647UENwOgxFSlgfGc8"


#Host URL
callurl = 'https://penguin-mint-extremely.ngrok-free.app/'
twiliosmsurl = 'https://penguin-mint-extremely.ngrok-free.app/sms'
